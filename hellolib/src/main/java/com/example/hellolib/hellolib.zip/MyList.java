package com.example.hellolib;

/**
 * Created by lenovo on 2018/4/9.
 */

public class MyList {
    public static void main(String[] args) {
        double[] myList = {1.9, 2.9, 3.4, 3.5};

        // 打印所有数组元素
        for (double element: myList) {
            System.out.println(element);
        }
    }
}
