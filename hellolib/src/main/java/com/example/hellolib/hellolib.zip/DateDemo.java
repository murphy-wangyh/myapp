package com.example.hellolib;
import java.util.Date;

/**
 * Created by lenovo on 2018/4/9.
 */

public class DateDemo {
        public static void main(String []args){
            Date date = new Date();
            System.out.println("日期："+date.toString());
        }
}
